// ParticipantRegistration.java
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.sql.*;
import java.util.regex.Pattern;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ParticipantRegistration extends JFrame {
    private static final String DB_PATH = "C:/path/to/VUE_Exhibition.accdb";
    private static final String DB_URL = "jdbc:ucanaccess://" + DB_PATH;

    private JTextField txtRegID, txtName, txtDept, txtPartner, txtContact, txtEmail;
    private JLabel lblImage;
    private String imagePath = null;

    public ParticipantRegistration() {
        setTitle("SALSA Festival - Participant Registration");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(new EmptyBorder(10,10,10,10));
        add(main);

        JPanel form = new JPanel();
        form.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6,6,6,6);
        c.anchor = GridBagConstraints.WEST;

        c.gridx = 0; c.gridy = 0;
        form.add(new JLabel("Registration ID:"), c);
        c.gridx = 1;
        txtRegID = new JTextField(20);
        form.add(txtRegID, c);

        c.gridx = 0; c.gridy++;
        form.add(new JLabel("Participant Name:"), c);
        c.gridx = 1;
        txtName = new JTextField(20);
        form.add(txtName, c);

        c.gridx = 0; c.gridy++;
        form.add(new JLabel("Department:"), c);
        c.gridx = 1;
        txtDept = new JTextField(20);
        form.add(txtDept, c);

        c.gridx = 0; c.gridy++;
        form.add(new JLabel("Dancing Partner:"), c);
        c.gridx = 1;
        txtPartner = new JTextField(20);
        form.add(txtPartner, c);

        c.gridx = 0; c.gridy++;
        form.add(new JLabel("Contact Number:"), c);
        c.gridx = 1;
        txtContact = new JTextField(20);
        form.add(txtContact, c);

        c.gridx = 0; c.gridy++;
        form.add(new JLabel("Email Address:"), c);
        c.gridx = 1;
        txtEmail = new JTextField(20);
        form.add(txtEmail, c);

        c.gridx = 0; c.gridy++;
        form.add(new JLabel("ID Image:"), c);
        c.gridx = 1;
        JPanel imgPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        JButton btnUpload = new JButton("Upload Image");
        btnUpload.addActionListener(e -> chooseImage());
        imgPanel.add(btnUpload);
        form.add(imgPanel, c);

        main.add(form, BorderLayout.WEST);

        JPanel right = new JPanel(new BorderLayout());
        right.setBorder(BorderFactory.createTitledBorder("ID Image Preview"));
        lblImage = new JLabel();
        lblImage.setHorizontalAlignment(SwingConstants.CENTER);
        lblImage.setPreferredSize(new Dimension(300, 300));
        right.add(lblImage, BorderLayout.CENTER);
        main.add(right, BorderLayout.EAST);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        JButton btnRegister = new JButton("Register");
        JButton btnSearch = new JButton("Search");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnClear = new JButton("Clear");
        JButton btnExit = new JButton("Exit");

        buttons.add(btnRegister);
        buttons.add(btnSearch);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnClear);
        buttons.add(btnExit);

        main.add(buttons, BorderLayout.SOUTH);

        btnRegister.addActionListener(e -> registerParticipant());
        btnSearch.addActionListener(e -> searchParticipant());
        btnUpdate.addActionListener(e -> updateParticipant());
        btnDelete.addActionListener(e -> deleteParticipant());
        btnClear.addActionListener(e -> clearForm());
        btnExit.addActionListener(e -> System.exit(0));
    }

    private void chooseImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "gif"));
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File f = chooser.getSelectedFile();
            imagePath = f.getAbsolutePath();
            setImagePreview(imagePath);
        }
    }

    private void setImagePreview(String path) {
        if (path == null) {
            lblImage.setIcon(null);
            lblImage.setText("No Image");
            return;
        }
        ImageIcon icon = new ImageIcon(path);
        Image img = icon.getImage();
        Image scaled = img.getScaledInstance(lblImage.getWidth(), lblImage.getHeight(), Image.SCALE_SMOOTH);
        lblImage.setIcon(new ImageIcon(scaled));
        lblImage.setText("");
    }

    private boolean validateInput(boolean requireRegID) {
        String reg = txtRegID.getText().trim();
        String name = txtName.getText().trim();
        String dept = txtDept.getText().trim();
        String contact = txtContact.getText().trim();
        String email = txtEmail.getText().trim();

        if (requireRegID && reg.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Registration ID is required.");
            return false;
        }
        if (name.isEmpty() || dept.isEmpty() || contact.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled.");
            return false;
        }
        if (!contact.matches("\\d{6,15}")) {
            JOptionPane.showMessageDialog(this, "Contact must be digits only (6-15).");
            return false;
        }
        if (!Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$").matcher(email).matches()) {
            JOptionPane.showMessageDialog(this, "Invalid email format.");
            return false;
        }
        return true;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    private void registerParticipant() {
        if (!validateInput(true)) return;
        String sql = "INSERT INTO Participants (RegID, Name, Department, Partner, Contact, Email, ImagePath) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, txtRegID.getText().trim());
            pst.setString(2, txtName.getText().trim());
            pst.setString(3, txtDept.getText().trim());
            pst.setString(4, txtPartner.getText().trim());
            pst.setString(5, txtContact.getText().trim());
            pst.setString(6, txtEmail.getText().trim());
            pst.setString(7, imagePath);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Participant registered successfully.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void searchParticipant() {
        String reg = txtRegID.getText().trim();
        if (reg.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Registration ID.");
            return;
        }
        String sql = "SELECT * FROM Participants WHERE RegID = ?";
        try (Connection conn = getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, reg);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    txtName.setText(rs.getString("Name"));
                    txtDept.setText(rs.getString("Department"));
                    txtPartner.setText(rs.getString("Partner"));
                    txtContact.setText(rs.getString("Contact"));
                    txtEmail.setText(rs.getString("Email"));
                    imagePath = rs.getString("ImagePath");
                    setImagePreview(imagePath);
                    JOptionPane.showMessageDialog(this, "Participant found.");
                } else {
                    JOptionPane.showMessageDialog(this, "No record found.");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void updateParticipant() {
        if (!validateInput(true)) return;
        String sql = "UPDATE Participants SET Name=?, Department=?, Partner=?, Contact=?, Email=?, ImagePath=? WHERE RegID=?";
        try (Connection conn = getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, txtName.getText().trim());
            pst.setString(2, txtDept.getText().trim());
            pst.setString(3, txtPartner.getText().trim());
            pst.setString(4, txtContact.getText().trim());
            pst.setString(5, txtEmail.getText().trim());
            pst.setString(6, imagePath);
            pst.setString(7, txtRegID.getText().trim());
            int rows = pst.executeUpdate();
            if (rows > 0) JOptionPane.showMessageDialog(this, "Updated successfully.");
            else JOptionPane.showMessageDialog(this, "No record found.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void deleteParticipant() {
        String reg = txtRegID.getText().trim();
        if (reg.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Registration ID.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this record?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        String sql = "DELETE FROM Participants WHERE RegID=?";
        try (Connection conn = getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, reg);
            int rows = pst.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Deleted successfully.");
                clearForm();
            } else {
                JOptionPane.showMessageDialog(this, "No record found.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void clearForm() {
        txtRegID.setText("");
        txtName.setText("");
        txtDept.setText("");
        txtPartner.setText("");
        txtContact.setText("");
        txtEmail.setText("");
        imagePath = null;
        lblImage.setIcon(null);
        lblImage.setText("No Image");
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new ParticipantRegistration().setVisible(true));
    }
}
