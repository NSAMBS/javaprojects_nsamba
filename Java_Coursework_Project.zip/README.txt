# Java Coursework Project

## Files Included
1. `ProjectileSimulation.java` — Console program for projectile motion calculations.
2. `ParticipantRegistration.java` — Swing GUI program integrated with MS Access database.

## Setup Instructions

### Projectile Simulation
Compile and run directly:
```
javac ProjectileSimulation.java
java ProjectileSimulation
```

### Participant Registration
1. Download UCanAccess JAR libraries and add them to your classpath.
2. Create MS Access database `VUE_Exhibition.accdb` with table `Participants`:
```
CREATE TABLE Participants (
    RegID TEXT(50) PRIMARY KEY,
    Name TEXT(100),
    Department TEXT(100),
    Partner TEXT(100),
    Contact TEXT(20),
    Email TEXT(100),
    ImagePath TEXT(255)
);
```
3. Update the `DB_PATH` in code to your actual `.accdb` path.
4. Compile and run:
```
javac -cp ".;lib/*" ParticipantRegistration.java
java -cp ".;lib/*" ParticipantRegistration
```
