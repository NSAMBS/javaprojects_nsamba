import java.util.Scanner;
import java.text.DecimalFormat;

public class ProjectileSimulation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#.####");

        final double g = 9.81;

        System.out.println("=== Projectile Motion Simulation ===");
        System.out.print("Enter initial velocity (m/s): ");
        while (!sc.hasNextDouble()) {
            System.out.print("Invalid. Enter a numeric initial velocity (m/s): ");
            sc.next();
        }
        double v = sc.nextDouble();

        System.out.print("Enter launch angle (degrees): ");
        while (!sc.hasNextDouble()) {
            System.out.print("Invalid. Enter a numeric launch angle (degrees): ");
            sc.next();
        }
        double angleDeg = sc.nextDouble();

        double theta = Math.toRadians(angleDeg);

        double timeOfFlight = (2 * v * Math.sin(theta)) / g;
        double maxHeight = (v * v * Math.pow(Math.sin(theta), 2)) / (2 * g);
        double range = (v * v * Math.sin(2 * theta)) / g;

        System.out.println("\n--- Results ---");
        System.out.println("Initial velocity: " + df.format(v) + " m/s");
        System.out.println("Launch angle: " + df.format(angleDeg) + " degrees");
        System.out.println("Time of flight: " + df.format(timeOfFlight) + " s");
        System.out.println("Maximum height: " + df.format(maxHeight) + " m");
        System.out.println("Horizontal range: " + df.format(range) + " m");

        System.out.println("\n(Assumptions: No air resistance; constant g = " + g + " m/s^2)");
        sc.close();
    }
}
